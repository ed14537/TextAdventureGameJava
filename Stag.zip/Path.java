class Path {

    private String start;
    private String end;

    Path (String s, String e) {
        start = s;
        end = e;
    }

    public String getStart() {
        return start;
    }

    public String getEnd() {
        return end;
    }

}
