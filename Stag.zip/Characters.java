class Characters extends Entity {


    Characters(String name, String description) {
        super(name, description);
    }
}
