public class Artifact extends Entity {


    Artifact(String name, String description) {
        super(name, description);
    }


}
